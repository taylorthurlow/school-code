#include <iostream>
#include <string>

#include "CruiseShip.h"

CruiseShip::CruiseShip() {
	name = "Unnamed";
	year = "0";
	maxCapacity = 1000;
}

CruiseShip::~CruiseShip() {
	
}

CruiseShip::CruiseShip(const CruiseShip &s1) {
	name = s1.getName();
	year = s1.getYear();
	maxCapacity = s1.getMaxCapacity();
}

CruiseShip::CruiseShip(std::string name, std::string year, int maxCapacity) {
	this->name = name;
	this->year = year;
	this->maxCapacity = maxCapacity;
}

void CruiseShip::setMaxCapacity(int maxCapacity) {
	this->maxCapacity = maxCapacity;
}

int CruiseShip::getMaxCapacity() const {
	return maxCapacity;
}

void CruiseShip::print() {
	std::cout << name << " has a max capacity of " << maxCapacity << " passengers." << std::endl;
}