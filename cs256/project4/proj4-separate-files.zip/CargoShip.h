#ifndef CARGOSHIP_H
#define CARGOSHIP_H

#include <string>
#include "Ship.h"

class CargoShip : public Ship {
private:
	int cargoCapacity;

public:
	CargoShip();
	~CargoShip();
	CargoShip(const CargoShip &s1);
	CargoShip(std::string name, std::string year, int cargoCapacity);
	void setCargoCapacity(int cargoCapacity);
	int getCargoCapacity() const;
	void print();
};

#endif