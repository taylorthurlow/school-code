#ifndef CRUISESHIP_H
#define CRUISESHIP_H

#include <string>
#include "Ship.h"

class CruiseShip : public Ship {
private:
	int maxCapacity;

public:
	CruiseShip();
	~CruiseShip();
	CruiseShip(const CruiseShip &s1);
	CruiseShip(std::string name, std::string year, int maxCapacity);
	void setMaxCapacity(int maxCapacity);
	int getMaxCapacity() const;
	void print();
};

#endif