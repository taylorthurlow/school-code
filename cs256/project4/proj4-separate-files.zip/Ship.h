#ifndef SHIP_H
#define SHIP_H

#include <string>

class Ship {
protected:
	std::string name;
	std::string year;

public:
	Ship();
	~Ship();
	Ship(const Ship &s1);
	Ship(std::string name, std::string year);
	std::string getName() const;
	void setName(std::string name);
	std::string getYear() const;
	void setYear(std::string year);
	virtual void print();
};

#endif