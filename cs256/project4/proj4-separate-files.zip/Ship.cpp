#include <iostream>
#include <string>

#include "Ship.h"

Ship::Ship() {
	name = "Unnamed";
	year = "0";
}

Ship::~Ship() {
	
}

Ship::Ship(const Ship &s1) {
	name = s1.getName();
	year = s1.getYear();
}

Ship::Ship(std::string name, std::string year) {
	this->name = name;
	this->year = year;
}

std::string Ship::getName() const {
	return name;
}

void Ship::setName(std::string name) {
	this->name = name;
}

std::string Ship::getYear() const {
	return year;
}

void Ship::setYear(std::string year) {
	this->year = year;
}

void Ship::print() {
	std::cout << name << " was built in " << year << "." << std::endl;
}