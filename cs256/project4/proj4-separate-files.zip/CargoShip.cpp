#include <iostream>
#include <string>

#include "CargoShip.h"

CargoShip::CargoShip() {
	name = "Unnamed";
	year = "0";
	cargoCapacity = 150000;
}

CargoShip::~CargoShip() {
	
}

CargoShip::CargoShip(const CargoShip &s1) {
	name = s1.getName();
	year = s1.getYear();
	cargoCapacity = s1.getCargoCapacity();
}

CargoShip::CargoShip(std::string name, std::string year, int cargoCapacity) {
	this->name = name;
	this->year = year;
	this->cargoCapacity = cargoCapacity;
}

void CargoShip::setCargoCapacity(int cargoCapacity) {
	this->cargoCapacity = cargoCapacity;
}

int CargoShip::getCargoCapacity() const {
	return cargoCapacity;
}

void CargoShip::print() {
	std::cout << name << " has a max capacity of " << cargoCapacity << " tons." << std::endl;
}